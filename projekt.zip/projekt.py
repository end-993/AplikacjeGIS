import arcpy, csv, sqlite3 as sl


try:
    hydro_meteo = arcpy.GetParameterAsText(0)
    baza = arcpy.GetParameterAsText(1)
    data_rok = arcpy.GetParameter(2)
    plik_wy = arcpy.GetParameterAsText(3)
    
    data_rok = int(data_rok)
    
    if hydro_meteo == "hydro":
        conn = sl.connect(baza)
        cursor = conn.cursor()
        cursor.execute("select * from hydro")
        
        con = sl.connect(plik_wy)
        cursor2 = con.cursor()
        cursor2.execute("""
                CREATE TABLE hydro(
                    stacja TEXT,
                    rzeka TEXT,
                    rok_hydro INTEGER,
                    miesiac_hydro INTEGER,
                    stan_wody INTEGER,
                    przeplyw FLOAT
            )
        """)
              
        for row in cursor:
            if row[2] == data_rok:
                stacja=row[0]
                rzeka=row[1]
                rok_hydro=int(row[2])
                miesiac_hydro=int(row[3]) 
                stan_wody=int(row[4]) 
                przeplyw=float(row[5])
                cursor2.execute('''INSERT INTO hydro(stacja, rzeka, rok_hydro, 
                                            miesiac_hydro, stan_wody, przeplyw)
                        VALUES (?,?,?,?,?,?)''',
                        (stacja, rzeka, rok_hydro, 
                          miesiac_hydro, stan_wody, przeplyw))
            
    else:
        conn = sl.connect(baza)
        cursor = conn.cursor()
        cursor.execute("select * from meteo")
        
        con = sl.connect(plik_wy) 
        cursor2 = con.cursor()    
        cursor2.execute("""
                CREATE TABLE meteo(
                stacja TEXT,
                rok INTEGER,
                miesiac INTEGER,
                suma_opadow FLOAT,
                dni_z_opad_snieg INTEGER,
                opad_maksymalny FLOAT
            )
        """)
            
        for row in cursor:
            if row[1] == data_rok:
                stacja=row[0]
                rok=int(row[1])
                miesiac=int(row[2])
                suma_opadow=float(row[3])
                dni_z_opad_snieg=int(row[4]) 
                opad_maksymalny=float(row[5])
                cursor2.execute('''INSERT INTO meteo(stacja, rok, miesiac, 
                               suma_opadow, dni_z_opad_snieg, opad_maksymalny)
                    VALUES (?,?,?,?,?,?)''',
                    (stacja, rok, miesiac, suma_opadow, 
                     dni_z_opad_snieg, opad_maksymalny))
    
    con.commit()
    con.close()
    
# ZAPISANIE PLIKU WYNIKOWEGO DO CSV
# for row in cursor:
#     if row[2] == data_rok:
#         # print(row)
#         arcpy.AddMessage(row)

# with open(plik_wy, "w") as csv_file:
#     csv_writer = csv.writer(csv_file)
#     csv_writer.writerow([i[0] for i in cursor.description])
#     for row in cursor:
#         if row[2] == data_rok:
#             csv_writer.writerow(row)

except:
    arcpy.AddMessage("Wystapil nieoczekiwany blad. Ponow probe, sprawdzajac przy tym poprawnosc danych")

finally:
    arcpy.AddMessage("Proces przebiegl pomyslnie")