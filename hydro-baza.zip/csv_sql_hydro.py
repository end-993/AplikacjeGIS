import sqlite3 as sl, csv


con = sl.connect('hydro.db')

cursor = con.cursor()

cursor.execute("""
        CREATE TABLE hydro(
            stacja TEXT,
            rzeka TEXT,
            rok_hydro INTEGER,
            miesiac_hydro INTEGER,
            stan_wody INTEGER,
            przeplyw FLOAT
    )
""")

pliki=['mies_2012.csv','mies_2013.csv',
       'mies_2014.csv','mies_2015.csv','mies_2016.csv','mies_2017.csv',
       'mies_2018.csv','mies_2019.csv','mies_2020.csv']

for x in pliki:
    file=open(x,"r")
    csv_reader = csv.reader(file,delimiter=';')
    for row in csv_reader:
        stacja=row[0]
        rzeka=row[1]
        rok_hydro=int(row[2])
        miesiac_hydro=int(row[3]) 
        stan_wody=int(row[4]) 
        przeplyw=float(row[5])
        cursor.execute('''INSERT INTO hydro(stacja, rzeka, rok_hydro, 
                                    miesiac_hydro, stan_wody, przeplyw)
                VALUES (?,?,?,?,?,?)''',
                (stacja, rzeka, rok_hydro, 
                  miesiac_hydro, stan_wody, przeplyw))

con.commit()
con.close()