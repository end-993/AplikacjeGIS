import arcpy, sqlite3 as sl


try:
    hydro_meteo = arcpy.GetParameterAsText(0)
    baza = arcpy.GetParameterAsText(1)
    data_rok = arcpy.GetParameter(2)
    plik_wy = arcpy.GetParameterAsText(3)
    if ".sqlite" not in plik_wy:
        plik_wy += ".sqlite"
    
    data_rok = int(data_rok)
    
    if hydro_meteo == "hydro":
        conn = sl.connect(baza)
        cursor = conn.cursor()
        cursor.execute("select * from hydro")
        
        con = sl.connect(plik_wy)
        cursor2 = con.cursor()
        cursor2.execute("""
                CREATE TABLE hydro(
                    kod_stacji INTEGER,
                    stacja TEXT,
                    rzeka TEXT,
                    rok_hydro INTEGER,
                    miesiac_hydro INTEGER,
                    stan_wody INTEGER,
                    przeplyw FLOAT
            )
        """)
              
        for row in cursor:
            if row[3] == data_rok:
                kod_stacji = int(row[0])
                stacja = row[1]
                rzeka = row[2]
                rok_hydro = int(row[3])
                miesiac_hydro = int(row[4]) 
                stan_wody = int(row[5]) 
                przeplyw = float(row[6])
                cursor2.execute('''INSERT INTO hydro(kod_stacji, stacja, rzeka, 
                                rok_hydro, miesiac_hydro, stan_wody, przeplyw)
                        VALUES (?,?,?,?,?,?,?)''',
                        (kod_stacji, stacja, rzeka, rok_hydro, 
                          miesiac_hydro, stan_wody, przeplyw))
            
    else:
        conn = sl.connect(baza)
        cursor = conn.cursor()
        cursor.execute("select * from meteo")
        
        con = sl.connect(plik_wy) 
        cursor2 = con.cursor()    
        cursor2.execute("""
                CREATE TABLE meteo(
                kod_stacji INTEGER,
                stacja TEXT,
                rok INTEGER,
                miesiac INTEGER,
                suma_opadow FLOAT,
                dni_z_opad_snieg INTEGER,
                opad_maksymalny FLOAT
            )
        """)
            
        for row in cursor:
            if row[2] == data_rok:
                kod_stacji = int(row[0])
                stacja = row[1]
                rok = int(row[2])
                miesiac = int(row[3])
                suma_opadow = float(row[4])
                dni_z_opad_snieg = int(row[5]) 
                opad_maksymalny = float(row[6])
                cursor2.execute('''INSERT INTO meteo(kod_stacji, stacja, rok, miesiac, 
                               suma_opadow, dni_z_opad_snieg, opad_maksymalny)
                    VALUES (?,?,?,?,?,?,?)''',
                    (kod_stacji, stacja, rok, miesiac, suma_opadow, 
                     dni_z_opad_snieg, opad_maksymalny))
    
    con.commit()
    con.close()
    
except:
    arcpy.AddMessage("Wystapil nieoczekiwany blad. Ponow probe, sprawdzajac przy tym poprawnosc danych")

finally:
    arcpy.AddMessage("Proces przebiegl pomyslnie")